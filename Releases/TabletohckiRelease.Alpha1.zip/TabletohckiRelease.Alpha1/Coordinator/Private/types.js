

exports.Services = {
    Watering: 'Svc_Watering',
    Kinect: 'Svc_Kinect',
    HttpListener: 'Svc_HttpListener',
    AdminUI: 'Svc_AdminUI',
    Coordinator: 'Coordinator'
};

